var firebaseConfig = {
    apiKey: "AIzaSyBzI238GP7Ik-AmLoHE3GAIt7gTkaIr8x8",
    authDomain: "uber-bdcfb.firebaseapp.com",
    databaseURL: "https://uber-bdcfb-default-rtdb.firebaseio.com",
    projectId: "uber-bdcfb",
    storageBucket: "uber-bdcfb.appspot.com",
    messagingSenderId: "1000032020464",
    appId: "1:1000032020464:web:9cd952b8080ab042e19f35",
    measurementId: "G-PFFFL6WYFX"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();